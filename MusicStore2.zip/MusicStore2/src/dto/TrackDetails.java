package dto;

public class TrackDetails {
 private int TrackId;
 private String Name;
 private int AlbumId;
 private int MediaTypeId;
 private int GenreId;
 private String Composer;
 private int Milliseconds;
 private int Bytes;
 private int UnitPrice;

public int getTrackId() {
	return TrackId;
}
public void setTrackId(int trackId) {
	TrackId = trackId;
}
public String getName() {
	return Name;
}
public int getAlbumId() {
	return AlbumId;
}
public int getMediaTypeId(){
	return MediaTypeId;
}

public int getGenreId(){
	return GenreId;
}
public String getComposer(){
	return Composer;
}
public int getMilliseconds(){
	return Milliseconds;
}
public int getBytes(){
	return Bytes;
	
}
public int getUnitPrice(){
	return UnitPrice;
}

public void setName(String name) {
	Name = name;
}

public void setAlbumId(int albumId) {
	AlbumId = albumId;
}
public void setMediaTypeId(int mediatypeId){
	MediaTypeId=mediatypeId;
}
public void setGenreId(int genreId){
	GenreId=genreId;
}
public void setComposer(String composer){
	Composer=composer;
}
public void setMilliseconds(int milli){
	Milliseconds=milli;
}
public void setBytes(int bytes){
	Bytes=bytes;
}
public void setUnitPrice(int unitprice){
	UnitPrice=unitprice;
}

public TrackDetails(int TrackId, String Name,int AlbumId,int MediaTypeId,int GenreId,String Composer,int Milliseconds,int UnitPrice) {
    this.TrackId = TrackId;
    this.Name = Name;
    this.AlbumId = AlbumId;
    this.MediaTypeId=MediaTypeId;
    this.GenreId=GenreId;
    this.Composer=Composer;
   this.Milliseconds=Milliseconds;
   this.Bytes=Bytes;
   this.UnitPrice=UnitPrice;

}

// @Override
public String toString() {
    return "Employee: TrackId = " + TrackId + "; Name = " + Name + "; AlbumId= " + AlbumId + "; MediaTypeId= " + MediaTypeId + "; GenreId= " + GenreId+ "; Composer= " + Composer+ "; Milliseconds= " + Milliseconds+ "; Bytes= " + Bytes+ "; UnitPrice= " + UnitPrice ;
}

}

