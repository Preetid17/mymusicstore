package dto;

public class AlbumDetails {
 private int ArtistId;
 private String Title;
 private int AlbumId;
public int getArtistId() {
	return ArtistId;
}
public void setArtistId(int artistId) {
	ArtistId = artistId;
}
public String getTitle() {
	return Title;
}
public void setTitle(String title) {
	Title = title;
}
public int getAlbumId() {
	return AlbumId;
}
public void setAlbumId(int albumId) {
	AlbumId = albumId;
}

public AlbumDetails(int ArtistId, String Title, int AlbumId) {
    this.ArtistId = ArtistId;
    this.Title = Title;
    this.AlbumId = AlbumId;

}

// @Override
public String toString() {
    return "Employee: ArtistId = " + ArtistId + "; Title = " + Title + "; AlbumId= " + AlbumId ;
}

}
