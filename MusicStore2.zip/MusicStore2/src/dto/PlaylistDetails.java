package dto;

public class PlaylistDetails {
 private int PlaylistId;
 private String Name;

public int getPlaylistId() {
	return PlaylistId;
}
public void setPlaylistId(int playlistId) {
	PlaylistId = playlistId;
}
public String getName() {
	return Name;
}
public void setName(String name) {
	Name = name;
}



public PlaylistDetails(int PlaylistId, String Name) {
    this.PlaylistId = PlaylistId;
    this.Name = Name;
   

}

// @Override
public String toString() {
    return "Employee: PlaylistId = " + PlaylistId + "; Name = " + Name  ;
}

}

