package dto;

public class Customer {
 private int CustomerId;
 private String FirstName;
 private String LastName;
 private String Company;
 private String Address;
 private String City;
 private String State;
 private String Country;
 private int PostalCode;
 private int Phone;
 private int Fax;
 private String Email;
 private String Password;
 private int SupportRepId;
 

public int getCustomerId() {
	return CustomerId;
}
public void setCustomerId(int customerId) {
	CustomerId = customerId;
}
public String getFirstName() {
	return FirstName;
}
public void setFirstName(String firstname) {
	FirstName = firstname;
}
public String getLastName() {
	return LastName;
}
public void setLastName(String lastname) {
	LastName = lastname;
}
public String getCompany() {
	return Company;
}
public void setCompany(String company) {
	Company = company;
}
public String getAddress() {
	return Address;
}
public void setAddress(String address) {
	Address = address;
}
public String getCity() {
	return City;
}
public void setCity(String city) {
	City = city;
}
public String getState() {
	return State;
}
public void setState(String state) {
	State = state;
}
public String getCountry() {
	return Country;
}
public void setCountry(String country) {
	Country = country;
}
public int getPostalCode() {
	return PostalCode;
}
public void setPostalCode(int postalcode) {
	PostalCode= postalcode;
}
public int getPhone() {
	return Phone;
}
public void setPhone(int phone) {
	Phone= phone;
}
public int getFax() {
	return Fax;
}
public void setFax(int fax) {
	Fax= fax;
}
public String getEmail() {
	return Email;
}
public void setEmail(String email) {
	Email = email;
}
public String getPassword() {
	return Email;
}
public void setPassword(String password) {
	Password = password;
}
public int getSupportRepId() {
	return SupportRepId;
}
public void setSupportRepId(int supportrepid) {
	SupportRepId= supportrepid;
}



public Customer(int CustomerId, String FirstName,String LastName,String Company,String Address, String City, String State, String Country, int PostalCode, int Phone,int Fax, String Email,String Password, int SupportRepId ) {
    this.CustomerId = CustomerId;
    this.FirstName = FirstName;
    this.LastName=LastName;
    this.Company=Company;
    this.Address=Address;
    this.City=City;
    this.State=State;
    this.Country=Country;
    this.PostalCode=PostalCode;
    this.Phone=Phone;
    this.Fax=Fax;
    this.Email=Email;
    this.Password=Password;
    this.SupportRepId=SupportRepId;
 
}

// @Override
public String toString() {
    return "Employee: CustomerId = " + CustomerId + "; FirstName = " + FirstName  + "; LastName = " + LastName  + "; Company = " + Company + "; Address = " + Address + "; City = " + City + "; State = " + State  + "; Country = " + Country  + "; PostalCode = " + PostalCode  + "; Phone = " + Phone + "; Fax= " + Fax + "; Email= " + Email + ";  Password= " + Password + "; SupportRepId = " + SupportRepId     ;
}

}


