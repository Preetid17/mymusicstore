package dto;

public class GenreDetails {
 private int GenreId;
 private String Name;

public int getGenreId() {
	return GenreId;
}
public void setGenreId(int genreId) {
	GenreId = genreId;
}
public String getName() {
	return Name;
}
public void setName(String name) {
	Name = name;
}



public GenreDetails(int GenreId, String Name) {
    this.GenreId = GenreId;
    this.Name = Name;
   

}

// @Override
public String toString() {
    return "Employee: GenreId = " + GenreId + "; Name = " + Name  ;
}

}

