package dto;

public class ArtistDetails {
 private int ArtistId;
 private String Name;

public int getArtistId() {
	return ArtistId;
}
public void setArtistId(int artistId) {
	ArtistId = artistId;
}
public String getName() {
	return Name;
}
public void setName(String name) {
	Name = name;
}



public ArtistDetails(int ArtistId, String Name) {
    this.ArtistId = ArtistId;
    this.Name = Name;
   

}

// @Override
public String toString() {
    return "Employee: ArtistId = " + ArtistId + "; Name = " + Name  ;
}

}

