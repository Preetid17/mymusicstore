package servlets;

import java.io.IOException;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dto.AlbumDetails;
import dto.ArtistDetails;
import dto.GenreDetails;
import dto.PlaylistDetails;
import dto.TrackDetails;
import servlets.ConnectivityTest;
import java.util.ArrayList;


@WebServlet("/ServletTest")
public class ServletTest extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con=null;
		String searchSong=(String)request.getParameter("searchSong");
		String searchby=(String)request.getParameter("searchby");
		try{ 			
			ArrayList<AlbumDetails> albDetailsList= new ArrayList<AlbumDetails>();
			ConnectivityTest test= new ConnectivityTest();
			con=test.connectToDatabase();
			PreparedStatement stmt = null;
			if(searchby.equalsIgnoreCase("album")){
				stmt=con.prepareStatement("select * from album where Title LIKE ?;");
				stmt.setString(1,"%" + searchSong + "%");
			}/*else if(searchby.equalsIgnoreCase("track")){
				PreparedStatement stmt=con.prepareStatement("select * from album");	
			}else if(searchby.equalsIgnoreCase("track")){
				PreparedStatement stmt=con.prepareStatement("select * from album");	
			}*/
			
		ResultSet rs=stmt.executeQuery();
			while(rs.next()){
				AlbumDetails albDetails=new AlbumDetails(0, null, 0);
				albDetails.setAlbumId(rs.getInt("AlbumId"));
				albDetails.setTitle(rs.getString("Title"));
				albDetails.setArtistId(rs.getInt("ArtistId"));
				albDetailsList.add(albDetails);
			}
			request.setAttribute("albDetailsList",albDetailsList);
			RequestDispatcher RequetsDispatcherObj =request.getRequestDispatcher("/jsp/ResultTest.jsp");
			RequetsDispatcherObj.forward(request, response);
		}
		catch(Exception e){
			e.printStackTrace();
			System.out.println("Exception is"+e);
		}

 try{
ArrayList<ArtistDetails> albDetailsList1= new ArrayList<ArtistDetails>();
			ConnectivityTest1 test1= new ConnectivityTest1();
			con=test1.connectToDatabase();
			PreparedStatement stmt1 = null;
			if(searchby.equalsIgnoreCase("artist")){
				stmt1=con.prepareStatement("select * from artist where Name LIKE ?;");
				stmt1.setString(1,"%" + searchSong + "%");
			}/*else if(searchby.equalsIgnoreCase("track")){
				PreparedStatement stmt=con.prepareStatement("select * from album");	
			}else if(searchby.equalsIgnoreCase("track")){
				PreparedStatement stmt=con.prepareStatement("select * from album");	
			}*/
			
			ResultSet rs1=stmt1.executeQuery();
			while(rs1.next()){
				ArtistDetails artDetails=new ArtistDetails(0, null);
				artDetails.setArtistId(rs1.getInt("ArtistId"));
				artDetails.setName(rs1.getString("Name"));
				
				albDetailsList1.add(artDetails);
			}
			request.setAttribute("albDetailsList1",albDetailsList1);
			RequestDispatcher RequetsDispatcherObj1 =request.getRequestDispatcher("/jsp/ResultTest1.jsp");
			RequetsDispatcherObj1.forward(request, response);
	
}


	
		
		catch(Exception e){
			e.printStackTrace();
			System.out.println("Exception is"+e);
		}
 try{
	 ArrayList<TrackDetails> albDetailsList2= new ArrayList<TrackDetails>();
	 			ConnectivityTest2 test2= new ConnectivityTest2();
	 			con=test2.connectToDatabase();
	 			PreparedStatement stmt2 = null;
	 			if(searchby.equalsIgnoreCase("track")){
	 				stmt2=con.prepareStatement("select * from track where Name LIKE ?;");
	 				stmt2.setString(1,"%" + searchSong + "%");
	 			}/*else if(searchby.equalsIgnoreCase("track")){
	 				PreparedStatement stmt=con.prepareStatement("select * from album");	
	 			}else if(searchby.equalsIgnoreCase("track")){
	 				PreparedStatement stmt=con.prepareStatement("select * from album");	
	 			}*/
	 			
	 			ResultSet rs2=stmt2.executeQuery();
	 			while(rs2.next()){
	 				TrackDetails trkDetails=new TrackDetails(0, null, 0, 0, 0, null, 0, 0);
	 				trkDetails.setTrackId(rs2.getInt("TrackId"));
	 				trkDetails.setName(rs2.getString("Name"));
	 				trkDetails.setAlbumId(rs2.getInt("AlbumId"));
	 				trkDetails.setMediaTypeId(rs2.getInt("MediaTypeId"));
	 				trkDetails.setGenreId(rs2.getInt("GenreId"));
	 				trkDetails.setComposer(rs2.getString("Composer"));
	 				trkDetails.setMilliseconds(rs2.getInt("Milliseconds"));
	 				trkDetails.setBytes(rs2.getInt("Bytes"));
	 				trkDetails.setUnitPrice(rs2.getInt("UnitPrice"));
	 				
	 				albDetailsList2.add(trkDetails);
	 			}
	 			request.setAttribute("albDetailsList2",albDetailsList2);
	 			RequestDispatcher RequetsDispatcherObj1 =request.getRequestDispatcher("/jsp/ResultTest2.jsp");
	 			RequetsDispatcherObj1.forward(request, response);
	 	
	 }


	 	
	 		
	 		catch(Exception e){
	 			e.printStackTrace();
	 			System.out.println("Exception is"+e);
	 		}
 try{
	 ArrayList<PlaylistDetails> albDetailsList3= new ArrayList<PlaylistDetails>();
	 			ConnectivityTest3 test3= new ConnectivityTest3();
	 			con=test3.connectToDatabase();
	 			PreparedStatement stmt3= null;
	 			if(searchby.equalsIgnoreCase("playlist")){
	 				stmt3=con.prepareStatement("select * from playlist where Name LIKE ?;");
	 				stmt3.setString(1,"%" + searchSong + "%");
	 			}/*else if(searchby.equalsIgnoreCase("track")){
	 				PreparedStatement stmt=con.prepareStatement("select * from album");	
	 			}else if(searchby.equalsIgnoreCase("track")){
	 				PreparedStatement stmt=con.prepareStatement("select * from album");	
	 			}*/
	 			
	 			ResultSet rs3=stmt3.executeQuery();
	 			while(rs3.next()){
	 				PlaylistDetails playDetails=new PlaylistDetails(0, null);
	 				playDetails.setPlaylistId(rs3.getInt("PlaylistId"));
	 				playDetails.setName(rs3.getString("Name"));
	 				
	 				albDetailsList3.add(playDetails);
	 			}
	 			request.setAttribute("albDetailsList3",albDetailsList3);
	 			RequestDispatcher RequetsDispatcherObj1 =request.getRequestDispatcher("/jsp/ResultTest3.jsp");
	 			RequetsDispatcherObj1.forward(request, response);
	 	
	 }


	 	
	 		
	 		catch(Exception e){
	 			e.printStackTrace();
	 			System.out.println("Exception is"+e);
	 		}
 try{
	 ArrayList<GenreDetails> albDetailsList4= new ArrayList<GenreDetails>();
	 			ConnectivityTest4 test4= new ConnectivityTest4();
	 			con=test4.connectToDatabase();
	 			PreparedStatement stmt4 = null;
	 			if(searchby.equalsIgnoreCase("genre")){
	 				stmt4=con.prepareStatement("select * from genre where Name LIKE ?;");
	 				stmt4.setString(1,"%" + searchSong + "%");
	 			}/*else if(searchby.equalsIgnoreCase("track")){
	 				PreparedStatement stmt=con.prepareStatement("select * from album");	
	 			}else if(searchby.equalsIgnoreCase("track")){
	 				PreparedStatement stmt=con.prepareStatement("select * from album");	
	 			}*/
	 			
	 			ResultSet rs4=stmt4.executeQuery();
	 			while(rs4.next()){
	 				GenreDetails genDetails=new GenreDetails(0, null);
	 				genDetails.setGenreId(rs4.getInt("GenreId"));
	 				genDetails.setName(rs4.getString("Name"));
	 				
	 				albDetailsList4.add(genDetails);
	 			}
	 			request.setAttribute("albDetailsList4",albDetailsList4);
	 			RequestDispatcher RequetsDispatcherObj1 =request.getRequestDispatcher("/jsp/ResultTest4.jsp");
	 			RequetsDispatcherObj1.forward(request, response);
	 	
	 }


	 	
	 		
	 		catch(Exception e){
	 			e.printStackTrace();
	 			System.out.println("Exception is"+e);
	 		}
 
	
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				System.out.println("Exception occured while closing connection is"+e);
			}
		
		}
	}

}
