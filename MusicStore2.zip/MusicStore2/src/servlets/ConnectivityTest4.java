package servlets;

import java.sql.*;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectivityTest4{ 
	static java.sql.Connection connectToDatabase () {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Found");
		} catch (Exception e) {
			System.out.println("Driver not found");
		}
		Connection con=null;
		try {
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/chinook","root","root/p4ssw0rd");
			System.out.println("Connection Successfull");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Exception"+e);
			
		}
		return con;

	}

	public static void main(String args[]){
		ConnectivityTest4 test4= new ConnectivityTest4();
		test4.connectToDatabase();
		
		
	}
}

