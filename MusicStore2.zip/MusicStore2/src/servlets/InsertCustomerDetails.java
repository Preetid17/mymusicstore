package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Statement;

import dto.AlbumDetails;
import dto.Customer;
import dto.Track;

/**
 * Servlet implementation class InsertCustomerDetails
 */
@WebServlet("/InsertCustomerDetails")
public class InsertCustomerDetails extends HttpServlet {
    private static final long serialVersionUID = 1L;


    public InsertCustomerDetails() {
        super();
    }


    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }



    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Connection con=null;
        try{         
            ArrayList<Customer> custList = new ArrayList<Customer>();
            Customer customer = new Customer(0, null, null, null, null, null, null, null, 0, 0, 0, null, null, 0);
            ConnectivityTest test= new ConnectivityTest();
            con=test.connectToDatabase();
            String supportId=request.getParameter("SupportRepId");
            PreparedStatement stmt = null;
            stmt=con.prepareStatement("select CustomerId from customer;");
            ResultSet rs=stmt.executeQuery();
            int rowCount = rs.last() ? rs.getRow() : 0;
            System.out.println("The count is " + rowCount);
            /*while(rs.next()){
                 System.out.println("The count is " + rs.getInt("COUNT"));
            }*/
            String query = " insert into customer (CustomerId,FirstName,LastName,Company,Address,City,State,Country,PostalCode,Phone,Fax,Email,SupportRepId,password)"
                    + " values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            // create the mysql insert preparedstatement
            stmt = con.prepareStatement(query);
            stmt.setInt(1,rowCount+1);
            stmt.setString (2,request.getParameter("FirstName"));
            stmt.setString (3,request.getParameter("LastName"));
            stmt.setString(4,request.getParameter("Company") );
            stmt.setString(5,request.getParameter("Address"));
            stmt.setString (6,request.getParameter("City"));
            stmt.setString (7, request.getParameter("State"));
            stmt.setString(8,request.getParameter("Country") );
            stmt.setString(9,request.getParameter("PostalCode"));
            stmt.setString (10,request.getParameter("Phone"));
            stmt.setString (11, request.getParameter("Fax"));
            stmt.setString(12, request.getParameter("Email"));
            stmt.setInt(13,3); 
            stmt.setString(14,request.getParameter("password"));
            int insert=stmt.executeUpdate();
            String result="";
            if(insert>0){
                result="Inserted Successfully";
            }else{
                result="Could not Insert Successfully";
            }
            request.setAttribute("result",result);
            RequestDispatcher RequetsDispatcherObj =request.getRequestDispatcher("/jsp/Customer-Registration.jsp");
            RequetsDispatcherObj.forward(request, response);
        }catch(Exception e){
            System.out.println("Exception is"+e);
        }
        finally{
            try {
                con.close();
            } catch (SQLException e) {
                System.out.println("Exception occured while closing connection is"+e);
            }
        }
    }
}