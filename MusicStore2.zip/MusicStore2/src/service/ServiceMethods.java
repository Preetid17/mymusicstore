package service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import dto.AlbumDetails;
import servlets.ConnectivityTest;

public class ServiceMethods {
	public ArrayList<AlbumDetails> albDetailsList(){
		return null;
	}

}
